package com.huawei.java.pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Site {

    // 边缘节点的编号（ID）
    private String siteName;
    // 边缘节点的总带宽
    private int totalBandWidth;
    // 边缘节点的分配之后剩余带宽
    private int residualBandWidth;
    // 5% 的数量
    private int percentFiveCNT;
    // 该边缘节点可以分配的客户节点
    private List<String> customList;
    // 当前时刻是否被使用
    private int beUsed;

    public Site(String siteName, int totalBandWidth, int residualBandWidth, int percentFiveCNT) {
        this.siteName = siteName;
        this.totalBandWidth = totalBandWidth;
        this.residualBandWidth = residualBandWidth;
        this.percentFiveCNT = percentFiveCNT;
        this.customList = new ArrayList<>();
        this.beUsed = 0;
    }

    public void setCustomList(List<String> customList) {
        this.customList = customList;
    }

    public int getBeUsed() {
        return beUsed;
    }

    public void setBeUsed(int beUsed) {
        this.beUsed = beUsed;
    }

    public List<String> getCustomList() {
        return customList;
    }

    public void addCustomList(String customID) {
        this.customList.add(customID);
    }

    public int getPercentFiveCNT() {
        return percentFiveCNT;
    }

    public void setPercentFiveCNT(int percentFiveCNT) {
        this.percentFiveCNT = percentFiveCNT;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public int getTotalBandWidth() {
        return totalBandWidth;
    }

    public void setTotalBandWidth(int totalBandWidth) {
        this.totalBandWidth = totalBandWidth;
    }

    public int getResidualBandWidth() {
        return residualBandWidth;
    }

    public void setResidualBandWidth(int residualBandWidth) {
        this.residualBandWidth = residualBandWidth;
    }

    @Override
    public String toString() {
        return "Site{" +
                "siteName='" + siteName + '\'' +
                ", totalBandWidth=" + totalBandWidth +
                ", residualBandWidth=" + residualBandWidth +
                '}';
    }
}
