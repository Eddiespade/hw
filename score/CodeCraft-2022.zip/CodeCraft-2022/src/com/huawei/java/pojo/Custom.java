package com.huawei.java.pojo;

import com.huawei.java.main.Main;

import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class Custom {

    // 当前客户有哪些满足qos要求的边缘节点  95分配
    private PriorityQueue<SatisfySite> satisfySites;
    private PriorityQueue<SatisfySite> copyOFSatisfy;
    // 平均分配
    private PriorityQueue<SatisfySite> satisfySiteList;
    private String customID;
    private int siteCount;

    public Custom(String customID) {
        this.siteCount = 0;
        this.satisfySites = new PriorityQueue<>((o, p) -> {
            // 首先按当前时刻是否被使用排序，再按剩余的白嫖数排序（大的在前），若一致，则按剩余带宽排序（小的在前）
            Site oSite = Main.siteMap.get(o.getSiteID());
            Site pSite = Main.siteMap.get(p.getSiteID());
            if (oSite.getBeUsed() != pSite.getBeUsed()) return oSite.getBeUsed() - pSite.getBeUsed();
            else {
                if (oSite.getPercentFiveCNT() != pSite.getPercentFiveCNT()) {
                    return pSite.getPercentFiveCNT() - oSite.getPercentFiveCNT();
                } else {
                    return oSite.getResidualBandWidth() - pSite.getResidualBandWidth();
                }
            }
        });
        this.customID = customID;
    }

    public PriorityQueue<SatisfySite> getSatisfySiteList() {
        this.satisfySiteList = new PriorityQueue<>((o, p) -> {
            // 首先按当前时刻是否被使用排序，再按剩余的白嫖数排序（大的在前），若一致，则按剩余带宽排序（小的在前）
            Site oSite = Main.siteMap.get(o.getSiteID());
            Site pSite = Main.siteMap.get(p.getSiteID());
            return pSite.getResidualBandWidth() - oSite.getResidualBandWidth();

        });
        PriorityQueue<SatisfySite> copy = getCopyOFSatisfy();
        while (!copy.isEmpty()) {
            satisfySiteList.add(copy.poll());
        }
        return satisfySiteList;
    }

    public void setSatisfySiteList(PriorityQueue<SatisfySite> satisfySiteList) {
        this.satisfySiteList = satisfySiteList;
    }

    public PriorityQueue<SatisfySite> getCopyOFSatisfy() {
        copyOFSatisfy = new PriorityQueue<>(satisfySites);
        return copyOFSatisfy;
    }

    public void setCopyOFSatisfy(PriorityQueue<SatisfySite> copyOFSatisfy) {
        this.copyOFSatisfy = copyOFSatisfy;
    }

    public int getSiteCount() {
        return siteCount;
    }

    public void setSiteCount(int siteCount) {
        this.siteCount = siteCount;
    }

    public void addSatisfySite(SatisfySite satisfySite) {
        siteCount++;
        satisfySites.add(satisfySite);
    }

    public PriorityQueue<com.huawei.java.pojo.SatisfySite> getSatisfySites() {
        return satisfySites;
    }

    public void setSatisfySites(PriorityQueue<com.huawei.java.pojo.SatisfySite> satisfySites) {
        this.satisfySites = satisfySites;
    }

    public String getCustomID() {
        return customID;
    }

    public void setCustomID(String customID) {
        this.customID = customID;
    }

    @Override
    public String toString() {
        return "Custom{" +
                "sites=" + satisfySites +
                ", customID='" + customID + '\'' +
                '}';
    }
}
