package com.huawei.java.pojo;

import java.util.Map;

public class DemandInfo {

    public String mtime;

    public Map<String, Integer> demands;

    public DemandInfo(String mtime, Map<String, Integer> demands) {
        this.mtime = mtime;
        this.demands = demands;
    }

}