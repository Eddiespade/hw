package com.huawei.java.utils;

import com.huawei.java.pojo.CustomNode;
import com.huawei.java.pojo.DemandInfo;
import com.huawei.java.pojo.RuralNode;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class FileUtil {

    private static final String defaultSiteBandwidthFile = "/data/site_bandwidth.csv";
    private static final String defaultQosFile = "/data/qos.csv";
    private static final String defaultDemandFile = "/data/demand.csv";
    private static final String defaultConfigFile = "/data/config.ini";
    private static final String defaultOutputFile = "/output/solution.txt";

    private static int qosLimitation;
    private static BufferedReader demandFileReader;
    private static String[] demandFileMetaInfo;


    public static void loadFiles() throws IOException {
        loadFiles(defaultConfigFile, defaultSiteBandwidthFile, defaultQosFile);
    }

    public static void loadFiles(String configFile, String siteBandwidthFile, String qosFile) throws IOException {
        // 如果输出文件存在则删除，保证输出文件最新
        File outputFile = new File(defaultOutputFile);
        if (outputFile.exists() && !outputFile.delete()) {
            throw new IOException("输出文件删除失败");
        }
        // 读取配置文件
        readFile(configFile, line -> {
            if (line.contains("qos_constraint")) {
                qosLimitation = Integer.parseInt(line.split("=")[1]);
            }
        });
        // 读取边缘节点带宽文件
        readFile(siteBandwidthFile, line -> {
            line = line.trim();
            if (!line.equals("") && !line.startsWith("site_name")) {
                String[] data = line.split(",");
                String ruralNodeId = data[0];
                RuralNode.ruralNodeMap.put(ruralNodeId, new RuralNode(ruralNodeId, Integer.parseInt(data[1])));
            }
        });
        // 读取qos文件
        readFile(qosFile, new LineHandler() {
            private String[] customNodes;

            @Override
            public void handle(String line) {
                line = line.trim();
                if (!line.equals("")) {
                    // 创建所有的用户节点
                    if (line.startsWith("site_name")) {
                        customNodes = line.split(",");
                        for (int i = 1; i < customNodes.length; i++) {
                            String siteName = customNodes[i];
                            CustomNode.customNodeMap.put(siteName, new CustomNode(siteName));
                        }
                    }
                    // 为客户节点添加到边缘节点之间的qos
                    else {
                        String[] qosInfo = line.split(",");
                        for (int i = 1; i < qosInfo.length; i++) {
                            String ruralNode = qosInfo[0];
                            String customNode = customNodes[i];
                            int qos = Integer.parseInt(qosInfo[i]);
                            // 如果超出时延限制，则不放到map中
                            if (qos < qosLimitation) {
                                CustomNode.customNodeMap.get(customNode).qosSet.add(ruralNode);
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * 获取下一个需求信息
     */
    public static DemandInfo getNextDemand() throws IOException {
        return getNextDemand(defaultDemandFile);
    }

    public static DemandInfo getNextDemand(String demandFile) throws IOException {
        if (demandFileReader == null) {
            demandFileReader = new BufferedReader(new FileReader(demandFile));
        }
        String line = demandFileReader.readLine();
        // 如果当前行不为空，则直接返回
        if (line != null) {
            if (line.startsWith("mtime")) {
                demandFileMetaInfo = line.split(",");
                line = demandFileReader.readLine();
            }
            line = line.trim();
            if (!line.equals("")) {
                String[] demands = line.split(",");
                Map<String, Integer> data = new HashMap<>();
                for (int i = 1; i < demands.length; i++) {
                    data.put(demandFileMetaInfo[i], Integer.valueOf(demands[i]));
                }
                return new DemandInfo(demands[0], data);
            }
        }
        // 如果为空则关闭流
        if (demandFileReader != null) {
            demandFileReader.close();
            demandFileReader = null;
        }
        return null;
    }


    /**
     * 文件读取
     */
    public static void readFile(String filepath, LineHandler handler) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filepath));
        String line = null;
        while ((line = reader.readLine()) != null) {
            handler.handle(line);
        }
        reader.close();
    }

    interface LineHandler {
        public void handle(String line);
    }

    public static BufferedWriter getOutputWriter() throws IOException {
        return new BufferedWriter(new FileWriter(defaultOutputFile, true));
    }

}
