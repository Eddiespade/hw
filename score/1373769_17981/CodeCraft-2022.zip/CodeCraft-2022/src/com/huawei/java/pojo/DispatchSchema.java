package com.huawei.java.pojo;


import com.huawei.java.utils.FileUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.*;

public class DispatchSchema {

    // 客户节点分配方案
    public static Map<String, List<String[]>> dispatchSchemas;

    // 客户节点已满足需求统计
    public static Map<String, Integer> customReceivedMap;

    // 边缘节点已分配需求统计
    public static Map<String, Integer> ruralDispatchedMap;

    // 输出文件
    public static BufferedWriter writer;

    /**
     * 初始化
     */
    public static void init() throws IOException {
        dispatchSchemas = new TreeMap<>();
        customReceivedMap = new HashMap<>();
        ruralDispatchedMap = new HashMap<>();
        writer = FileUtil.getOutputWriter();
    }

    /**
     * 记录
     */
    public static void record() throws IOException {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, List<String[]>> dispatchSchema : dispatchSchemas.entrySet()) {
            String customNode = dispatchSchema.getKey();
            List<String[]> dispatchInfo = dispatchSchema.getValue();
            builder.append(customNode).append(":");
            for (String[] item : dispatchInfo) {
                if (!item[1].equals("0")) builder.append("<").append(item[0]).append(",").append(item[1]).append(">,");
            }
            int len = builder.length();
            builder.replace(len - 1, len, "\n");
        }
        writer.write(builder.toString());
        writer.flush();
    }

    /**
     * 文件持久化
     */
    public static void finish() throws IOException {
        writer.close();
    }

    /**
     * 添加新的分配策略
     */
    public static void addDispatchSchema(String customNode, String ruralNode, int size) {
        int ruralNodeDispatchedSize = DispatchSchema.ruralDispatchedMap.getOrDefault(ruralNode, 0);
        int customReceivedSize = DispatchSchema.customReceivedMap.getOrDefault(customNode, 0);
        DispatchSchema.ruralDispatchedMap.put(ruralNode, ruralNodeDispatchedSize + size);
        DispatchSchema.customReceivedMap.put(customNode, customReceivedSize + size);
        // 添加分配策略
        List<String[]> schemas = DispatchSchema.dispatchSchemas.getOrDefault(customNode, new ArrayList<>());
        schemas.add(new String[]{ruralNode, String.valueOf(size)});
        DispatchSchema.dispatchSchemas.put(customNode, schemas);
    }
}
