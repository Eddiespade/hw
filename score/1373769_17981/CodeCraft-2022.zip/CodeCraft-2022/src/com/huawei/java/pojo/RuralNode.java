package com.huawei.java.pojo;

import java.util.HashMap;
import java.util.Map;

public class RuralNode {

    public static Map<String, RuralNode> ruralNodeMap = new HashMap<>();

    public String siteName;

    public Integer bandwidth;

    public RuralNode(String siteName, Integer bandwidth) {
        this.siteName = siteName;
        this.bandwidth = bandwidth;
    }
}
