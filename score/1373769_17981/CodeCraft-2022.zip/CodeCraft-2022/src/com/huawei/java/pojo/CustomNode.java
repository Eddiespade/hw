package com.huawei.java.pojo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CustomNode {

    public static Map<String, CustomNode> customNodeMap = new HashMap<>();

    public String siteName;

    // 当前节点的qps
    public Set<String> qosSet;

    public CustomNode(String siteName) {
        this.siteName = siteName;
        this.qosSet = new HashSet<>();
    }

    /**
     * 获取满足条件的节点个数
     */
    public int getAccessibleNodeCount(int totalDemand) {
        int count = qosSet.size();
        while (count > 0) {
            if (checkCurrentNodeCount(totalDemand, count))
                break;
            count--;
        }
        return count;
    }

    /**
     * 判断当前分配的边缘节点个数是否满足要求
     */
    public boolean checkCurrentNodeCount(int totalDemand, int count) {
        // 计算当前边缘节点应该分配的流量大小
        int size = totalDemand / count;
        if (totalDemand % count != 0) size += 1;
        int extraSize = totalDemand;
        // 如果当前分配方案满足要求的话，则直接更新当前节点的 qosMap
        for (String ruralNode : qosSet) {
            // 计算边缘节点的剩余流量是否满足需求
            int ruralNodeExtraSize = RuralNode.ruralNodeMap.get(ruralNode).bandwidth - DispatchSchema.ruralDispatchedMap.getOrDefault(ruralNode, 0);
            // 最后一个边缘节点划分的流量少于平均值
            size = Math.min(extraSize, size);
            if (ruralNodeExtraSize < size) {
                continue;
            }
            extraSize -= size;
            if (--count == 0) {
                return true;
            }
        }
        return false;
    }
}