package com.huawei.java.main;

import com.huawei.java.pojo.CustomNode;
import com.huawei.java.pojo.DemandInfo;
import com.huawei.java.pojo.DispatchSchema;
import com.huawei.java.pojo.RuralNode;
import com.huawei.java.utils.FileUtil;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class Main {

	public static void main(String[] args) throws IOException {
		// 加载用户节点、边缘节点信息
		FileUtil.loadFiles();
		// 遍历需求信息
		DemandInfo demandInfo = null;
		while ((demandInfo = FileUtil.getNextDemand()) != null) {
			// 重新设置新的配置方案
			DispatchSchema.init();
			Map<String, Integer> customReceivedMap = DispatchSchema.customReceivedMap;
			Map<String, Integer> ruralDispatchedMap = DispatchSchema.ruralDispatchedMap;
			Map<String, List<String[]>> dispatchSchemas = DispatchSchema.dispatchSchemas;
			// 尝试获取分配方案
			handle(demandInfo.demands);
			// 将当前的解决方案写入文件中，并更新相关的记录信息
			DispatchSchema.record();
		}
		// 关闭流
		DispatchSchema.finish();
	}

	/**
	 * 进行当前节点的分配
	 */
	private static void handle(Map<String, Integer> demands) {
		// 首先按照客户节点可满足难度进行排序
		PriorityQueue<CustomNode> customNodes = getDispatchQueue(demands);
		// 按照顺序把客户需求分配到边缘服务器上
		// 获取当前可分配的边缘节点个数
		while (customNodes.size() > 0) {
			CustomNode customNode = customNodes.poll();
			int totalDemand = demands.get(customNode.siteName);
			int ruralNodeCount = customNode.getAccessibleNodeCount(totalDemand);
			// 如果可分配的边缘节点个数为0，则直接推出
			if (ruralNodeCount == 0) {
				System.exit(0);
			}
			// 对边缘节点的流量进行划分
			partitionFlow(customNode, totalDemand, ruralNodeCount);
			// 重新获取需要分配的节点
			customNodes = getDispatchQueue(demands);
		}
	}

	/**
	 * 获取客户节点分配优先级队列
	 */
	private static PriorityQueue<CustomNode> getDispatchQueue(Map<String, Integer> demands) {
		// 优先级队列，按照当前客户节点可分配节点的个数、分片大小进行排序
		PriorityQueue<CustomNode> dispatchCustomQueue = new PriorityQueue<>((o1, o2) -> {
			int count1 = o1.getAccessibleNodeCount(demands.get(o1.siteName));
			int count2 = o2.getAccessibleNodeCount(demands.get(o2.siteName));
			if (count1 != count2) {
				return count1 - count2;
			}
			return demands.get(o1.siteName) - demands.get(o2.siteName);
		});
		// 遍历所有的客户节点，将其中仍需要进行分配的节点拿出来
		for (Map.Entry<String, CustomNode> item : CustomNode.customNodeMap.entrySet()) {
			int totalDemand = demands.getOrDefault(item.getKey(), 0);
			int hasDispatchedDemand = DispatchSchema.customReceivedMap.getOrDefault(item.getKey(), 0);
			if (totalDemand > hasDispatchedDemand) {
				dispatchCustomQueue.add(item.getValue());
			}
		}
		return dispatchCustomQueue;
	}

	/**
	 * 通过边缘节点为客户节点化分流量
	 */
	private static void partitionFlow(CustomNode customNode, int totalDemand, int count) {
		// 计算当前边缘节点应该分配的流量大小
		String customNodeSiteName = customNode.siteName;
		int size = totalDemand / count;
		if (totalDemand % count != 0) size += 1;
		int extraSize = totalDemand;
		// 如果当前分配方案满足要求的话，则直接更新当前节点的 qosMap
		for (String ruralNode : customNode.qosSet) {
			// 计算边缘节点的剩余流量是否满足需求
			int ruralNodeExtraSize = RuralNode.ruralNodeMap.get(ruralNode).bandwidth - DispatchSchema.ruralDispatchedMap.getOrDefault(ruralNode, 0);
			// 最后一个边缘节点划分的流量少于平均值
			size = Math.min(extraSize, size);
			if (ruralNodeExtraSize < size) {
				continue;
			}
			extraSize -= size;
			// 更新分配方案
			DispatchSchema.addDispatchSchema(customNodeSiteName, ruralNode, size);
			if (--count == 0) {
				break;
			}
		}
	}
}
